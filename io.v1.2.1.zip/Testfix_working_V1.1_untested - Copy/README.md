### Information

The plugin's general purpose is to prevent griefers and make moderation easier. If you wish to help developing the plugin, feel free!

### Credits

The original discordplugin was made by J-VdS, you can visit his repository here:
https://github.com/J-VdS/DiscordPlugin
