package mindustry.plugin.discordcommands;

import org.javacord.api.event.message.MessageCreateEvent;

public abstract class MessageCreatedListener {
    public void run(MessageCreateEvent messageCreateEvent){

    }
}
